function [a, b, r] = minimaxfit(x,y)
n = size(x);
A = zeros(n(2),n(1) + 2);
B = zeros(1,n(1));
for j = 1:n(2)
    for i = 1:n(1)
        B(i) = x(i,j);
    end
    A(j,:) = [B, 1, -1];
end
C = zeros(n(2),n(1) + 2);
for j = 1:n(2)
    for i = 1:n(1)
        B(i) = x(i,j);
    end
    C(j,:) = [-B, -1, -1];
end
D = [A;C];
b = [y -y];
f = [0 0 0 0 1];
t = linprog(f,D,b);
% a = transpose(t(1:n(1)));
a = t(1:n(1));
b = t(n(1)+1);
r = t(end);
end