% clear; close all; clc;
 
fileGong = 'gong.wav';
 
[y,Fs]=audioread(fileGong);
%sound(y,Fs)
 
p = 300;
T = length(y) - 1;
 
%% Nejmenší ètverce
M1 = nan(T-p+1,p+1);
M1(1:end,1) = 1;
for row = 1:length(M1)
    yStart = p+row-1;
    M1(row, 2:end) = y(yStart:-1:row);
end
 
b1 = y(p+1:T+1);
 
a2 = M1\b1;
% minA = norm(M*a2-b)^2
%  
% %% QR rozklad
% a1 = solve_ls(M,b);
% distance = norm(a1-a2)
%  
% %% Syntetický gong
% y2 = nan(T+1,1);
% y2(1:p) = y(1:p);
% 
% as = a1(2:p+1).';
% % for index = p+1:T+1  
% %     ys = y2(index-1:-1:index-p);
% %     y2(index) = a1(1) + as*ys;
% % end
% % plot(1:T+1, y, 1:T+1, y2)
% % grid on
% % grid minor
% % ylim([-0.5 0.5])
% % xlabel('Èas')
% % ylabel('Signál')
% % legend('Originální gong', 'Syntetický gong')
% % title('Porovnání syntetického a originálního gongu')
% %  
% %sound(y2,Fs)