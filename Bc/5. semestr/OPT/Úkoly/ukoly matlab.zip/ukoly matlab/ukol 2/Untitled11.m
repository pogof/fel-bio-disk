close all;
clear;
clc;
%% Use of ar_fit_model:
[y, Fs] = audioread('gong.wav');
p = 300;  
size_y = size(y);
k = size_y(1);
M = ones(k-p,p+1);
for j=p:size_y(1)-1
   for i=1:p
       M(j-p+1,i+1)=y(j-i+1);
   end
end
b = y(p+1:size(y));
a = M\b;