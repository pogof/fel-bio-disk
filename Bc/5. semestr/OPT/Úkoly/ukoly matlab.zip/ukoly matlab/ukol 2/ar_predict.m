function [y] = ar_predict(a, y0, N)
p = length(a) - 1; 
y = zeros(N, 1);
y(1:p) = y0;
a=a.';
for i = p+1:N
    ypomoc = y(i-1:-1:i-p);
    y(i) = a(1) + a(2:p+1)*ypomoc;
end

end

