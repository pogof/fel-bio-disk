function [d, e, f] = fit_circle_hom(X)
% function [d e f] = fit_circle_hom(X)
%
% INPUT: 
% X: n-by-2 vector
%    with data
%
% OUTPUT: 
% quadric coordinates of the circle
[N,~] = size(X);
C = (X(:,1)).^2 +(X(:,2)).^2;
A = [C,X(:,1),X(:,2),ones(N,1)];
[~,~,V] = svd(A);
d = V(2,end)/V(1,end);
e = V(3,end)/V(1,end);
f = V(4,end)/V(1,end);
 
 
% [N,~] = size(X);
% A = [X(:,1),X(:,2),ones(N,1)];
% d = zeros(1,N);
% for i = 1:N
%    d(1,i) = -(X(i,1))^2 -(X(i,2))^2; 
% end
% x = A\transpose(d);
% d1 = x(1);
% e1 = x(2);
% f1 = x(3);
% a =(d1^2+e1^2+f1^2-1)^0.5;
% d = d1/a;
% e = e1/a;
% f = f1/a;

end
