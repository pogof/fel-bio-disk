function [d, e, f] = fit_circle_nhom(X)
% function [d e f] = fit_circle_nhom(X)
%
% INPUT: 
% X: n-by-2 vector
%    with data
%
%
% OUTPUT: 
% quadric coordinates of the circle
[N,~] = size(X);
A = [X(:,1),X(:,2),ones(N,1)];
d = zeros(1,N);
for i = 1:N
   d(1,i) = -(X(i,1))^2 -(X(i,2))^2; 
end
x = A\transpose(d);
d = x(1);
e = x(2);
f = x(3);
end
