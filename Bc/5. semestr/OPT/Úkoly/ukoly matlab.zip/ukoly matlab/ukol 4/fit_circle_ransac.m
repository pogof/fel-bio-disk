function [x1, y1, r1] = fit_circle_ransac(X, num_iter, threshold)
% function [x0 y0 r] = fit_circle_ransac(X, num_iter, threshold)
%
% INPUT: 
% X: n-by-2 vector
%    with data
% num_iter: number of RANSAC iterations
% threshold: maximal  distance of an inlier from the circumference
%
% OUTPUT: 
% cartesian coordinates of the circle
[N,~] = size(X);
k = 0;
max = 0;
 for i = 1:num_iter
     rn = randi([1,N],1,3);
     X1 = [X(rn(1),1), X(rn(1),2);X(rn(2),1), X(rn(2),2);X(rn(3),1), X(rn(3),2)];
     [d, e, f] = fit_circle_nhom(X1);
     [x0, y0, r] = quad_to_center(d, e, f);
     d = dist(X,x0,y0,r);
     for j = 1:N
         if abs(d(j)) < threshold
             k = k + 1;
         end
         if k > max
             max = k;
             x1 = x0;
             y1 = y0;
             r1 = r;
         end
     end
     k = 0;
 end
end
