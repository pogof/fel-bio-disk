function [x, y, r] = GN_iter(X, x0, y0, r0)
% [x y r] = GN_iter(X, x0, y0, r0)
%
% makes the Gauss-Newton iteration.
%
% INPUT:
% X: n-by-2 matrix
%    with data
% x0, y0 are the coordinates of the circle center.
% r0 is the circle radius
%
% OUTPUT:
% coordinates and radius after one step of GN method.
%
% % x = x0;ro^2/0+1;
% % r = r0;
a = size(X);
D = zeros(a(1),3);
A = zeros(a(1),1);
for i = 1:a(1)
    A(i) = sqrt((X(i,1)-x0)^2 + (X(i,2)-y0)^2) - r0;
    d1 = -(X(i,1)-x0)/sqrt((X(i,1)-x0)^2 + (X(i,2)-y0)^2);
    d2 = -(X(i,2)-y0)/sqrt((X(i,1)-x0)^2 + (X(i,2)-y0)^2);
    D(i,:) = [d1,d2,-1];
end

k = pinv(D) * A;
x = x0 - k(1,1);
y = y0 - k(2,1);
r = r0 - k(3,1);
end
