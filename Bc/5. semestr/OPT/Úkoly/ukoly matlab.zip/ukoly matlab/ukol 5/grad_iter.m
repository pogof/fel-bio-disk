function [x, y, r] = grad_iter(X, x0, y0, r0, a)
d = dist(X, x0, y0, r0);
sum = zeros(1,3);
[N,~] = size(X);
for i = 1:N
%     xa(i) = X(i,1); 
%     ya(i) = X(i,2); 
%     n(i) = norm([x0-xa,y0-ya]);
    d1 = -(X(i,1)-x0)/sqrt((X(i,1)-x0)^2 + (X(i,2)-y0)^2);
    d2 = -(X(i,2)-y0)/sqrt((X(i,1)-x0)^2 + (X(i,2)-y0)^2);
    D(i,:) = [d1,d2,-1];
    t = d(1,i)*D(i,:);
    sum = sum + t;
end
k = 2*a*sum;
x = x0 - k(1,1);
y = y0 - k(1,2);
r = r0 - k(1,3);


end
 
