function [a, c, r] = mini(x,y)
[m, n] = size(x);

    f = [zeros(1,m) 0 0 1]; % x = [a1 ... am b k z]

     

    %podmínky zmíněné na začátku kódu

    A = [-x' -ones(n,1) y' -ones(n,1); x' ones(n,1) -y' -ones(n,1)]; % [-ax -b +ky -z; ax b -ky -z]<= 0 ----[-x' -1 y' -1; x' 1 -y' -1]

    b = zeros(2*n,1);

     

    % rovnost ==> zajištění, že k = 1

    Aeq = [zeros(1,m) 0  1 0]; 

    beq = 1; 

 

    % vyřešení úlohy

    [vysl,r] = linprog(f,A,b,Aeq,beq); %ok

 

    %získání hledaných výsledků z výstupu ==> ok

    a = vysl(1:end-3); % první tři hodnoty 

    c = vysl(end-2); % třetí hodnota odzadu