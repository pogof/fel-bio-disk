function [a, b, r] = minimaxfit(x,y)
m = size(x);
k = m(2);
A = [-x' -ones(k,1) y' -ones(k,1)
     x' ones(k,1) -y' -ones(k,1)];
b = zeros(2*k,1);
f = [zeros(1,m(1)) 0 0 1];
Aeq = [zeros(1,m(1)) 0  1 0];
beq = 1;
[t,r] = linprog(f,A,b,Aeq,beq);
a = t(1:m(1));
b = t(m(1)+1);
end