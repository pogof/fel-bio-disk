function x = vyhra2(c,k,m)
A = [-c(1), 0, 0, 1;
    0, -c(2), 0, 1;
    0, 0, -c(3), 1;
    -1, 0, 0, 0;
    0, -1, 0, 0;
    0, 0, -1, 0;
    0, 0, 0, -1];
b = [0 0 0 -m -m -m 0];
f = [0 0 0 -1];
Aeq = [1 1 1 0];
beq = k;
x = linprog(f,A,b,Aeq,beq);
x = x(1:end - 1);
end