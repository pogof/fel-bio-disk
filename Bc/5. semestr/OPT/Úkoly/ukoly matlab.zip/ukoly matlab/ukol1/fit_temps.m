function [x] = fit_temps(t, T,omega)

sin_x = sin(t*omega);
cos_x = cos(t*omega);
A = [ones(size(t)) t sin_x cos_x];
x = A\T;

end