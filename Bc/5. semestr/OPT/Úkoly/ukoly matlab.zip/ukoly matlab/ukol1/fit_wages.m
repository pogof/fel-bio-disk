function [x] = fit_wages(t, M)

A = [ones(size(M)) t];
x = A\M;

%NEBO
%chceme predstavit rovnice v formatu: Ax-b=0
% A_plus = inv(A'*A)*A';
% x = A_plus*M;
end