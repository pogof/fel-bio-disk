close all;
clear;
clc;

data = load('mzdy.txt','-ascii');
t = data(:,1);
M = data(:,2);

x = fit_wages(t,M);

scatter(t,M)
hold on
plot([0 2010],[x(2)*0+x(1) x(2)*2010+x(1)]);
xlim([2000 2010])
hold on

% M = quarter2_2009(x);
% scatter(2009.25,M)


