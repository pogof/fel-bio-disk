close all;
clear;
clc;

data = load('teplota.txt','-ascii');
t = data(:,1);
T = data(:,2);
omega = 2*pi/365;

x = fit_temps(t,T,omega);

scatter(t,T)
hold on
t = 0:1090;
y = x(1)+x(2)*t+x(3)*sin(t*omega)+ x(4)*cos(t*omega);
plot(t,y);

