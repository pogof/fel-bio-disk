function drawfitline(A)
[U, C] = fitlin(A, 1);
B = U*C;
hold on;
min_bx = B(1,1);
max_bx = B(1,1);

min_by = B(2,1);
max_by = B(2,1);

first = 1;
last = 1;
for n = 1:size(A,2)
    A_x = A(1,n);
    A_y = A(2,n);
    B_x = B(1,n);
    B_y = B(2,n);
    
    if max_by < B_y
        max_by = B_y;
    end
    if max_bx < B_x
        max_bx = B_x;
        last = n;
    end
    
    if min_by > B_y
        min_by = B_y;
    end
    
    if min_bx > B_x
        min_bx = B_x;
        first = n;
    end
    plot(A_x, A_y, 'xr');
    plot([A_x; B_x], [A_y; B_y], '-r');
end

plot([B(1,first); B(2,first)], [B(1,last); B(2,last)], '-g');
hold off;
axis equal;
end

