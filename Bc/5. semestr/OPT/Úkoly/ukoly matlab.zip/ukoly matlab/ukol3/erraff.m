function d = erraff(A)
b0 = mean(A, 2);
B = A - b0;
h = cumsum(eig(B*transpose(B)));
d = [h(size(h,1)-1:-1:1); 0];


