function [U,C,b0] = fitaff(A,k)
b0= mean(A,2);
[U,C] = fitlin((A-b0), k);
end
