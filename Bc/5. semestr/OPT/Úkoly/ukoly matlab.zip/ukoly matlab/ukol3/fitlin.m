function [U,C] = fitlin(A,k)
[Q,~] = eig(A*transpose(A));
s = size(Q,2);
U = Q(:,s-k+1:s);
C = transpose(U)*A;
end


