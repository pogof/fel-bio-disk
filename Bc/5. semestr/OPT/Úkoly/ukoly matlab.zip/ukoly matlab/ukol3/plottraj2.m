function plottraj2(C)
plot(C(1,:),C(2,:));
end

