function d = erraff(A)
b0 = mean(A, 2);
B = A - b0;
helper = cumsum(eig(B*transpose(B)));
d = [helper(size(helper,1)-1:-1:1); 0];
end
