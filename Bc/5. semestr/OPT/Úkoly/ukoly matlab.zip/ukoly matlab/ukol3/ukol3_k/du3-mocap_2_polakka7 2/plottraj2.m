function plottraj2(C)
% function plottraj2(C)
%
% INPUT: 
% C: 2-by-m matrix
%    with data
%
plot(C(1,:),C(2,:));
end



